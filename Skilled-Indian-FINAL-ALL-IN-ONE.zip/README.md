# Skilled Indian Android App

This project wraps the live Skilled Indian Netlify website in an Android WebView.

## IMPORTANT

Edit:
app/src/main/java/com/skilledindian/app/MainActivity.java

Replace:
https://YOUR-NETLIFY-SITE.netlify.app/

with the real HTTPS URL of your Netlify website.

## Build APK

Push to the `main` branch, then open:

GitHub → Actions → Build Skilled Indian APK

The workflow builds a debug APK and uploads it as the artifact:

Skilled-Indian-APK

The APK can then be downloaded from the successful workflow run under Artifacts.

## Why the app loads the live Netlify site

The app loads the live HTTPS website so your Netlify Forms and JavaScript continue to work. Website updates can appear in the app without rebuilding the APK.

## Build system

Android Gradle Plugin 8.7.3
Gradle 8.9
Java 17
Compile SDK 35
