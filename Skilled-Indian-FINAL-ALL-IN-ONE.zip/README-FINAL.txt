SKILLED INDIAN - FINAL WEBSITE + ANDROID APK PROJECT

Upload the CONTENTS of this ZIP to the ROOT of the GitHub repository.

Required structure:
index.html
netlify.toml
build.gradle
settings.gradle
gradle.properties
app/
.github/workflows/main.yml

APK:
GitHub -> Actions -> Build Skilled Indian APK -> Run workflow
After success -> Artifacts -> Skilled-Indian-APK

IMPORTANT:
Before building, open:
app/src/main/java/com/skilledindian/app/MainActivity.java
and replace:
https://YOUR-NETLIFY-SITE.netlify.app/
with the real Netlify URL.

Do not put this ZIP itself inside the GitHub repository.
Extract it first, then upload the files/folders.
